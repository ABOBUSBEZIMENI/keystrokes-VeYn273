package dev.keystrokes;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Оверлей клавиш: рисует мини-клавиатуру (1-5, Tab, QWERT, Caps, ASDFG,
 * Shift, ZXCV, Ctrl, Alt, Space) и мышь. Нажатая клавиша подсвечивается белым.
 */
public class KeystrokesClient implements ClientModInitializer {

    // Положение оверлея на экране (левый верхний угол)
    private static final int ORIGIN_X = 10;
    private static final int ORIGIN_Y = 10;

    private static final int KEY_H = 18;

    private static final int COLOR_BG = 0xB0000000;        // тёмный фон
    private static final int COLOR_BG_PRESSED = 0xF0FFFFFF; // белый фон при нажатии
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_TEXT_PRESSED = 0xFF000000;

    private record Key(String label, int glfwKey, int x, int y, int w) {}

    private static final Key[] KEYS = {
            // ряд цифр
            new Key("1", GLFW.GLFW_KEY_1, 20, 0, 18),
            new Key("2", GLFW.GLFW_KEY_2, 40, 0, 18),
            new Key("3", GLFW.GLFW_KEY_3, 60, 0, 18),
            new Key("4", GLFW.GLFW_KEY_4, 80, 0, 18),
            new Key("5", GLFW.GLFW_KEY_5, 100, 0, 18),
            // Tab + QWERT
            new Key("tab", GLFW.GLFW_KEY_TAB, 0, 20, 36),
            new Key("Q", GLFW.GLFW_KEY_Q, 40, 20, 18),
            new Key("W", GLFW.GLFW_KEY_W, 60, 20, 18),
            new Key("E", GLFW.GLFW_KEY_E, 80, 20, 18),
            new Key("R", GLFW.GLFW_KEY_R, 100, 20, 18),
            new Key("T", GLFW.GLFW_KEY_T, 120, 20, 18),
            // Caps + ASDFG
            new Key("caps", GLFW.GLFW_KEY_CAPS_LOCK, 0, 40, 44),
            new Key("A", GLFW.GLFW_KEY_A, 48, 40, 18),
            new Key("S", GLFW.GLFW_KEY_S, 68, 40, 18),
            new Key("D", GLFW.GLFW_KEY_D, 88, 40, 18),
            new Key("F", GLFW.GLFW_KEY_F, 108, 40, 18),
            new Key("G", GLFW.GLFW_KEY_G, 128, 40, 18),
            // Shift + ZXCV
            new Key("shift", GLFW.GLFW_KEY_LEFT_SHIFT, 0, 60, 52),
            new Key("Z", GLFW.GLFW_KEY_Z, 56, 60, 18),
            new Key("X", GLFW.GLFW_KEY_X, 76, 60, 18),
            new Key("C", GLFW.GLFW_KEY_C, 96, 60, 18),
            new Key("V", GLFW.GLFW_KEY_V, 116, 60, 18),
            // Ctrl, Alt, Space
            new Key("ctrl", GLFW.GLFW_KEY_LEFT_CONTROL, 0, 80, 36),
            new Key("alt", GLFW.GLFW_KEY_LEFT_ALT, 40, 80, 36),
            new Key("", GLFW.GLFW_KEY_SPACE, 80, 80, 80),
    };

    @Override
    public void onInitializeClient() {
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("keystrokes", "overlay"),
                (context, tickCounter) -> render(context)
        );
    }

    private static void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.currentScreen != null) {
            return; // не рисуем поверх меню/инвентаря
        }

        // Окно, в котором сейчас идёт отрисовка (поток рендера)
        long window = GLFW.glfwGetCurrentContext();
        if (window == 0L) {
            return;
        }

        TextRenderer font = client.textRenderer;

        for (Key key : KEYS) {
            boolean pressed = GLFW.glfwGetKey(window, key.glfwKey()) == GLFW.GLFW_PRESS;
            drawBox(context, ORIGIN_X + key.x(), ORIGIN_Y + key.y(), key.w(), KEY_H, pressed);

            if (!key.label().isEmpty()) {
                int textWidth = font.getWidth(key.label());
                int tx = ORIGIN_X + key.x() + (key.w() - textWidth) / 2;
                int ty = ORIGIN_Y + key.y() + (KEY_H - 8) / 2 + 1;
                context.drawText(font, key.label(), tx, ty,
                        pressed ? COLOR_TEXT_PRESSED : COLOR_TEXT, false);
            }
        }

        drawMouse(context, window);
    }

    /** Рисует мышь справа от клавиатуры: ЛКМ, ПКМ и колесо. */
    private static void drawMouse(DrawContext context, long window) {
        boolean left = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean middle = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;

        int mx = ORIGIN_X + 170;
        int my = ORIGIN_Y;

        // корпус мыши
        context.fill(mx, my, mx + 30, my + 46, 0xB0000000);
        // левая и правая кнопки
        context.fill(mx + 2, my + 2, mx + 14, my + 20, left ? COLOR_BG_PRESSED : 0xFF303030);
        context.fill(mx + 16, my + 2, mx + 28, my + 20, right ? COLOR_BG_PRESSED : 0xFF303030);
        // колесо
        context.fill(mx + 13, my + 6, mx + 17, my + 16, middle ? COLOR_BG_PRESSED : 0xFF2E7DD6);
    }

    private static void drawBox(DrawContext context, int x, int y, int w, int h, boolean pressed) {
        context.fill(x, y, x + w, y + h, pressed ? COLOR_BG_PRESSED : COLOR_BG);
    }
}
