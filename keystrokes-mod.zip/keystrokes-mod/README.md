# Keystrokes (Fabric, Minecraft 1.21.11)

Показывает на экране нажатые клавиши (1-5, Tab, QWERT, Caps, ASDFG, Shift, ZXCV, Ctrl, Alt, Space) и кнопки мыши. Нажатая клавиша подсвечивается белым.

Нужен Fabric Loader и Fabric API для 1.21.11.

## Сборка
- На компьютере: `./gradlew build` -> `build/libs/Keystrokes.jar`
- Через GitHub: загрузите проект в репозиторий -> вкладка Actions -> workflow "build" -> Artifacts -> Keystrokes-jar

Положение оверлея: константы ORIGIN_X / ORIGIN_Y в `KeystrokesClient.java`.
